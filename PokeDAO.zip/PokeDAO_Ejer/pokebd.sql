DROP schema IF EXISTS `pokedb` ;

CREATE SCHEMA IF NOT EXISTS `pokedb`;

USE `pokedb` ;


DROP TABLE IF EXISTS `pokemon`;
CREATE TABLE pokemon (
    id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    height INT,
    weight INT,
    type VARCHAR(255),
    ability_name VARCHAR(255),
    ability_effect TEXT
);

DROP TABLE IF EXISTS `form`;
CREATE TABLE form (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pokemon_id INT,
    back_default VARCHAR(255),
    back_shiny VARCHAR(255),
    front_default VARCHAR(255),
    front_shiny VARCHAR(255),
    FOREIGN KEY (pokemon_id) REFERENCES pokemon(id)
);

DROP TABLE IF EXISTS `crie`;
CREATE TABLE crie (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pokemon_id INT,
    latest VARCHAR(255),
    legacy VARCHAR(255),
    FOREIGN KEY (pokemon_id) REFERENCES pokemon(id)
);

DROP TABLE IF EXISTS `stat`;
CREATE TABLE stat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    base_stat INT
);

DROP TABLE IF EXISTS `pokemon_stat`;
CREATE TABLE pokemon_stat (
    pokemon_id INT,
    stat_id INT,
    PRIMARY KEY (pokemon_id, stat_id),
    FOREIGN KEY (pokemon_id) REFERENCES pokemon(id),
    FOREIGN KEY (stat_id) REFERENCES stat(id)
);

DROP TABLE IF EXISTS `move`;
CREATE TABLE move (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(255),
    power INT
);

DROP TABLE IF EXISTS `pokemon_move`;
CREATE TABLE pokemon_move (
    pokemon_id INT,
    move_id INT,
    PRIMARY KEY (pokemon_id, move_id),
    FOREIGN KEY (pokemon_id) REFERENCES pokemon(id),
    FOREIGN KEY (move_id) REFERENCES move(id)
);

SELECT * FROM pokemon;
SELECT * FROM move;
SELECT * FROM move m, pokemon p, pokemon_move pm
WHERE m.name = 'movimiento-que-ha-usado-el-pokemon-ganador' AND p.id = pm.pokemon_id AND m.id = pm.move_id;