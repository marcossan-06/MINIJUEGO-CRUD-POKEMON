package org.manu;

import org.manu.connect.ApiPokemon;
import org.manu.dao.PokemonDAO;
import org.manu.dbconnection.ConexionBD;
import org.manu.pojo.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class Main {
    private static final String BASE_URL = "https://pokeapi.co/api/v2/";
    public static void main(String[] args) {
    // Generamos un ObjetoDao
    PokemonDAO pokemonDAO = new PokemonDAO();



    // Escribe aquí el código para poder saber si tenemos pokemons en la base de datos.
    String sql = "SELECT count(*) AS cont FROM pokemon";
    boolean hayPokemons = false;
    Connection conn = null;
    try {
        conn = ConexionBD.getConnection();
        conn.setAutoCommit(false);
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                if (rs.getInt("cont") > 0) {
                    hayPokemons = true;
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        if (conn != null) {
            try {
                conn.close(); // Cerrar la conexión
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }


        // Si no hay pokemon debes descargarlos
    if (!hayPokemons)
    {
    List<Pokemon> pokemonList = ApiPokemon.recogePokemons(BASE_URL,20);
    for (Pokemon pokemon : pokemonList) {
        pokemonDAO.createPokemon(pokemon);
        }
    if (pokemonList.isEmpty()) return;
    }

    // En este punto ya podemos listar todos los Pokémon
    List<Pokemon> allPokemon = pokemonDAO.getAllPokemon();
        for (Pokemon pokemon : allPokemon) {
        System.out.println("Pokémon: " + pokemon.getName());
        System.out.println("  Movimientos: " + pokemon.getMoves().stream()
                .map(Move::getName)
                .collect(Collectors.joining(", ")));
        System.out.println("  Estadísticas: " + pokemon.getStats().stream()
                .map( stat -> stat.getStat().getName() + " (" + stat.getBaseStat() + ")")
                .collect(Collectors.joining(", ")));
    }
    System.out.println("~".repeat(40));

    // Generamos una Batalla de Pokemon

    Random rand = new Random();
    Pokemon p1 = allPokemon.get(rand.nextInt(allPokemon.size()));
    Pokemon p2 = allPokemon.get(rand.nextInt(allPokemon.size()));
    // Leo los pokemons que se enfrentan

    System.out.println("JUGADOR 1: ");
    System.out.println(pokemonDAO.readPokemon(p1.getId()));

    System.out.println("JUGADOR 2: ");
    System.out.println(pokemonDAO.readPokemon(p2.getId()));

    // He hecho que el método lucha devuelva el pokemon perdedor para este eliminarlo de la base de datos cuando pierda.
    LuchaPokemon luchaPokemon = new LuchaPokemon();
    Pokemon perdedor = luchaPokemon.lucha(p1,p2);
    if (perdedor != null) {
        if (perdedor == p1) {
            pokemonDAO.deletePokemon(p1.getId());
            luchaPokemon.getMove2().setPower((int) (luchaPokemon.getMove2().getPower()*1.5));
            pokemonDAO.updatePokemon(p2);
        }
        else if (perdedor == p2) {
            pokemonDAO.deletePokemon(p2.getId());
            luchaPokemon.getMove1().setPower((int) (luchaPokemon.getMove1().getPower()*1.5));
            pokemonDAO.updatePokemon(p1);
        }
    }
}
}